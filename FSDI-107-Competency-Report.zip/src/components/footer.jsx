import './footer.css';

const Footer = () => {
    return (
        <div className="footer">
            <h5>Sneak Shop &copy; 2022</h5>
        </div>
    );
}

export default Footer;