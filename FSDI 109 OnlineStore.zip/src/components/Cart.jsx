import './Cart.css';

const Cart = () => {
    return (
        <div>
            <h1>Your cart</h1>

        </div>
    )
};

export default Cart;