import './Cart.css';

const Cart = () => {
    return (
        <div>
            <h1>Your cart</h1>

            <table className="table table-hover">

            </table>
        </div>
    )
}